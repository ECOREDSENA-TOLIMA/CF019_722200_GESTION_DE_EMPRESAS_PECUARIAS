function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6koi0vIGdOK":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

