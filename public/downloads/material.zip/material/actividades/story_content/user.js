function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6kyYC20AZrF":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

